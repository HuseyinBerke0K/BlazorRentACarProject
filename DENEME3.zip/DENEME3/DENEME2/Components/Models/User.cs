using AracKiralama.Models;
using YourProject.Data;
using Microsoft.EntityFrameworkCore;
using System.Net.NetworkInformation;
using System.Text.Json.Serialization;

namespace AracKiralama.Models
{
    public class Customer
    {
        public string Name { get; set; } = "";
        public string Surname { get; set; } = "";
        public string Password { get; set; } = "";
        public string Email { get; set; } = "";
        public string PhoneNumber { get; set; } = "";
        public string IdentityNumber { get; set; } = "";
        public string Address { get; set; } = "";
    }
    public class LoginModel
    {
        [JsonPropertyName("Email")]
        public string Email { get; set; }

        [JsonPropertyName("Password")]
        public string Password { get; set; }
    }


}

public class AuthService
{
    private readonly AppDbContext _context;

    public AuthService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<Customer?> LoginAsync(string email, string password)
    {
        return await _context.Customers
            .FirstOrDefaultAsync(u => u.Email == email && u.Password == password);
    }
}




