namespace AracKiralama.Models
{
    public class RentOffice
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
