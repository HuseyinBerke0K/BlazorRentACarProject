using AracKiralama.Models;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

public class CustomerService
{
    private readonly HttpClient _httpClient;

    public CustomerService(HttpClient httpClient)
    {
        _httpClient = httpClient;
        _httpClient.BaseAddress = new Uri("http://84.247.20.87:32794/");  // API'nin temel adresini belirtiyoruz
    }
   
    public async Task<List<Customer>> GetAppUsersAsync()
    {
        var response = await _httpClient.GetFromJsonAsync<List<Customer>>("api/Customer");
        return response;
    }
}
