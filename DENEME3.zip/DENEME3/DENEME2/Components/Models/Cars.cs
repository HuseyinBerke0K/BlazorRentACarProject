using AracKiralama.Models;
using YourProject.Data;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace YourProject.Models
{
    [Table("product")] 
    public class Product
    {
        [Column("Id")]
        public Guid Id { get; set; }

        [Column("RentId")]
        public List<Guid>? RentId { get; set; } 

        [Column("RentOfficeId")]
        public Guid RentOfficeId { get; set; }

        [Column("Name")]
        public string Name { get; set; }

        [Column("Description")]
        public string Description { get; set; }

        [Column("Price")]
        public decimal Price { get; set; }

        [Column("Quantity")]
        public int Quantity { get; set; }

        [Column("ImageUrl")]
        public string ImageUrl { get; set; }

        [Column("Category")]
        public string Category { get; set; }

        [Column("IsAvailable")]
        public bool IsAvailable { get; set; }

        [Column("IsDeleted")]
        public bool IsDeleted { get; set; }
    }
    public class SelectedCarService
    {
        public Product? SelectedCar { get; set; }
    }
}