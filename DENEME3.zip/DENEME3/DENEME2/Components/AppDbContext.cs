using AracKiralama.Models;
using Microsoft.EntityFrameworkCore;
using YourProject.Models;

namespace YourProject.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Product> Products { get; set; }
        public DbSet<Customer> Customers { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>().HasNoKey(); 
            modelBuilder.Entity<Product>().ToTable("product", schema: "dbo");
            modelBuilder.Entity<Product>().HasKey(p => p.RentOfficeId);
            modelBuilder.Entity<Product>().Property(p => p.RentId).HasConversion(v => v,v => v);
        }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    }
}
